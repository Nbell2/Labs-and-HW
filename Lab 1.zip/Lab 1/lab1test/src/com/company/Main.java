package com.company;
//Nathan Bell nbell2@umbc.edu
import java.util.Scanner;


public class Main {

    public static void main(String[] args) {
        Scanner input = new Scanner ( System.in );
        int age;
        double payrate;
        float hours;
        double grossPay; // Calculated weekly pay before taxes
        double taxDeduction; // gross pay * 14%
        double netPay; // Calculated weekly pay after taxes
        System.out.print("Employee name: ");
        String name = input.nextLine();

        System.out.printf("Employee age: ");
        age = input.nextInt();


        System.out.printf("Enter hourly rate for %s: $", name);
        payrate = input.nextDouble();


        System.out.printf("total hours worked: ");
        hours = input.nextFloat();

        grossPay = payrate * hours;
        System.out.println("gross pay: " + grossPay);
        System.out.printf("gross pay: $%.2f\n", grossPay);
        System.out.println();
        taxDeduction = grossPay * .14;
        System.out.printf("federal taxes: $%.2f\n", taxDeduction);
        System.out.println();
        netPay = grossPay - taxDeduction;
        System.out.printf("net pay: $%.2f\n", netPay);
        System.out.println();
        input.nextLine();



    }

}


