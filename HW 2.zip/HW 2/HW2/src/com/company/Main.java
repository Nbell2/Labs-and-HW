package com.company;
import java.util.Scanner;


public class Main {

    public static void main(String[] args) {
        char[] helloArray = { 'H', 'e', 'l', 'l', 'o', ' ','W','o','r','l','d' };
        String helloString = new String(helloArray);
        String Str4 = new String("This IS REALLY NOT IMMUTABLE!!");
        System.out.println( helloString );

        int len = helloString.length();
        System.out.println( "String Length is : " + len );

        System.out.println(helloString.substring(10) );

        System.out.println( helloString.indexOf( helloString, 15 ));

        char result= helloString.charAt(8);
        System.out.println(result);

        System.out.println(helloString.toUpperCase() );

        for (String retval: helloString.split("-")) {
            System.out.println(retval);

            helloString.contains("_");
            System.out.println("Methods returns: " + retval);

            helloString.equalsIgnoreCase( Str4 );
            System.out.println("Returned Value = " + retval );
        }

        System.out.println("Pick two integers and enter them here: ");
        int num1, num2, choice;
        boolean check = false;

        Scanner keyboard = new Scanner(System.in);
        num1 = keyboard.nextInt();
        num2 = keyboard.nextInt();

        do{

        System.out.println("1: Addition");
        System.out.println("2: Subtract");
        System.out.println("3: Multiply");
        System.out.println("4: Divide");
        System.out.println("0: Quit");
        System.out.println("Your Selection");
        Double one, two, three, four, zero;
        System.out.println("Enter Choice: ");
        choice = keyboard.nextInt();
        if (choice == 1){
            System.out.println(num1 + num2);
        }
       else if (choice == 2){
            System.out.println(num1 - num2);
        }
       else if (choice == 3){
            System.out.println(num1 * num2);
        }
       else if (choice == 4){
            System.out.println(num1 / num2);
        }
       else if (choice == 0){
            System.out.println("This way to the exit.");
            System.exit(0);
        }
       else {
            System.out.println("Error, entered wrong number.");
        }
        }while (!check);
        System.out.print("Finished.");
    }

}









