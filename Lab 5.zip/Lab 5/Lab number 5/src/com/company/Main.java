package com.company;
//Nate Bell nbell2@umbc.edu
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner input= new Scanner(System.in);
        System.out.println("Lab 5 Part 2");
        int y,z,sum,sub,prod,divide;
        System.out.println("Please enter two values");
        y= input.nextInt();
        z= input.nextInt();
        sum= add(y,z);
        sub= subtraction(y,z);
        prod= multiplication(y,z);
        divide= division(y,z);
        System.out.println("The sum of the two values is: " + sum);
        System.out.println("The two numbers subtracted equals: " + sub);
        System.out.println("The product is equal to: " + prod);
        System.out.println("The quotient is equal to: " + divide);
        System.out.println("");
        System.out.println("Lab 5 Part 3");
        Book one= new Book();
        Book two= new Book();
        System.out.println(one.bookmethod("Life of Pi"));
        System.out.println(one.bookmethod(50));
        System.out.println(one.bookmethod(true));
        System.out.println(one.bookmethod(30.0,"Steve"));
        System.out.println("");
        System.out.println(two.bookmethod("Goosebumps"));
        System.out.println(two.bookmethod(25));
        System.out.println(two.bookmethod(false));
        System.out.println(two.bookmethod(40.0,"Jeff"));
    }
    public static int add(int val1, int val2) {
        int result;
        return (val1+ val2);
    }
    public static int subtraction(int num1, int num2) {
        int result;
        return(num1-num2);
    }
    public static int multiplication(int seq1, int seq2) {
        int result;
        return (seq1*seq2);
    }
    public static int division(int quot1, int quot2) {
        int result;
        return (quot1/quot2);

    }
    public static void Myname(){
        System.out.println("Nathan");}
}
