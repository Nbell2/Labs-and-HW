package com.company;

//Nate Bell nbell2@umbc.edu

public class Book {
        private static String author= "Nathan Bell";
        private static String title= "My World";
        private static int pagenum= 250;
        private static double price= 50.0;
        private static boolean hardcover=true;


        public static String bookmethod(String k) {
            title= k;
            return title;
        }
        public static String bookmethod(int l){
            pagenum= 100;
            return("There are " + pagenum + " pages in the book" );
        }
        public static String bookmethod(boolean h) {
            hardcover=h;
            return("The book is hardcover: " + hardcover);
        }
        public static String bookmethod(double r, String g) {
            price=r;
            author= g;
            return ("The price of the novel is " + r + " And the author is " + g);
        }
    }
