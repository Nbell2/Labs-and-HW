package com.company;

/**
 * Created by Natan on 10/27/16.
 */
public class triangle {
    public static void main(String[] args){
    final int MAX_ROW = 10;

        for (int i=1; i <= MAX_ROW; i++)
        {
            for (int j = MAX_ROW; j>=1; j--)
            {
                if(j>=i)
                System.out.print("*");
        }
        System.out.println();
        }
    }
}
