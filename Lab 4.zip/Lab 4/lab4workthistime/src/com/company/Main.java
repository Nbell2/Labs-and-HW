package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

            String quit;

            do{

                Scanner scan= new Scanner(System.in);
                System.out.println("Enter three test scores");
                double grade1 = scan.nextDouble();
                double grade2 = scan.nextDouble();
                double grade3 = scan.nextDouble();
                double avg = (grade1+grade2+grade3)/3;
                System.out.println("Average: "+avg);
                scan = new Scanner(System.in);
                System.out.print("Do you want to average another? or enter Q to quit: ");
                quit=scan.nextLine();

            }while(!quit.equalsIgnoreCase("q"));
        }
    }

