package com.company;

//Nathan Bell nbell2@umbc.edu
public class Main {

    public static void main(String[]args){

        //HW1 part1
        //arithmetical
        // + operator
        int myfirstInt= 7;
        int mysecondInt=147;
        int plusOperator= myfirstInt+mysecondInt;
        System.out.println ( "Using + operator " + plusOperator);

        // Minus
        int minusOperator= myfirstInt-mysecondInt;
        System.out.println ( "Using + operator " + minusOperator);

        // Multiplication
        int multiplicationOperator= myfirstInt*mysecondInt;
        System.out.println ( "Using + operator " + multiplicationOperator);

        // Division
        int divisionOperator= myfirstInt/mysecondInt;
        System.out.println ( "Using + operator " + divisionOperator);

        // Modulus
        int modulusOperator= myfirstInt%mysecondInt;
        System.out.println ( "Using + operator " + modulusOperator);

        // plusplus
        int plusplusOperator= myfirstInt++;
        System.out.println ( "Using + operator " + plusplusOperator);

        //minusminus
        int minusminusOperator= myfirstInt--;
        System.out.println ( "Using + operator " + minusminusOperator);

        //HW1 part2 ==,!=,>,<, <=, >=
        // Comparision operator
        //== operator
        boolean equalequalInt=(7==7);
        System.out.println ("String comparision " + equalequalInt);
        boolean doesntequalInt=(7!=7);
        System.out.println ("String comparision " + doesntequalInt);
        boolean greaterthanInt=(7>7);
        System.out.println ("String comparision " + greaterthanInt);
        boolean lessthanInt=(7<7);
        System.out.println ("String comparision " + lessthanInt);
        boolean lessthanequalInt=(7<=7);
        System.out.println ("String comparision " + lessthanequalInt);
        boolean greaterthanequalInt=(7>=7);
        System.out.println ("String comparision " + greaterthanequalInt);

    }
}