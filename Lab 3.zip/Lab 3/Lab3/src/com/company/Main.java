package com.company;
//Nathan Bell nbell2@umbc.edu
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

    Scanner scan = new Scanner(System.in);
        int num1;
        num1 = (int)Math.random()* 99 + 10;
        String concatenatedName;

        System.out.print("Please enter your First Name:  \n");
        String first = scan.nextLine().toUpperCase();
        int length = first.length();

        System.out.print("Please enter your Last Name:  \n");
        String last = scan.nextLine().toLowerCase();

        System.out.print(first.charAt(length-1));
        concatenatedName = num1 + last ;
        System.out.print(concatenatedName);

    }
}
